# 嘉訊知識圖譜（115年1–9月）

這是一個純靜態 GitHub Pages 網站，將 PDF 內容整理成「月份 → 內容頁 → 主題」的互動知識圖譜，並使用 **MiniSearch** 做全文搜尋。

## 部署到 GitHub Pages

1. 在 GitHub 建立一個新的 Repository。
2. 將 `index.html` 上傳到 Repository 根目錄。
3. 到 **Settings → Pages**。
4. `Build and deployment` 選擇 **Deploy from a branch**。
5. Branch 選 `main`、Folder 選 `/ (root)`，儲存。
6. 等待約 1–2 分鐘後，GitHub 會提供 Pages 網址。

`index.html` 已把知識資料內嵌，因此只上傳這一個檔案即可運作。`source-data.json` 是方便未來維護與再次加工的結構化資料。

## 功能

- MiniSearch 全文、作者、標籤、期別搜尋
- 前綴搜尋與模糊比對
- 月份、主題篩選
- 互動式知識圖譜（Cytoscape.js）
- 點選文章節點查看 PDF 擷取原文
- 點選主題節點查看所有關聯頁面

## 外部套件

- MiniSearch 7.1.2（jsDelivr CDN）
- Cytoscape.js 3.30.4（jsDelivr CDN）

因此使用者瀏覽網站時需可連線至 jsDelivr。
